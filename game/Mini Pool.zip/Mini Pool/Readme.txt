Title: Mini Pool
Description:The aim of the game is to first pot the pink ball as this usually has the least number of seconds on it and thus it's best to get rid of this ball first. Then one by one pot the red balls before the time runs out. 


Downloaded from http://www.1station.org

Bookmark our site if you like US!


All the games belong to their respective owners.
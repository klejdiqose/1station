Title: Swords and Sandals 2
Description:The objective of the game is to simply win tournaments and survive. This sequel offers a lot more than the first game, it now has ranged weapons and magic spells that you can use. Try to get as far as you can. A tip to this game is to try several stat builds. Some builds have advantages over others. Choose wisely! Source from http://www.newgrounds.com/portal/view/358324


Downloaded from http://www.1station.org

Bookmark our site if you like US!


All the games belong to their respective owners.
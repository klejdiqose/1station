Title: Temple Guardian
Description:The objectives of the game are the same as any tower defense game, stop the enemies from reaching the end of the maze. You are in charge of guarding the sacred Temple of Lightening and Fire. Build arrow and catapult towers and other facilities to defeat waves of attack by alien animals and weird objects. May the Sacred Temple bless its worshipers!


Downloaded from http://www.1station.org

Bookmark our site if you like US!


All the games belong to their respective owners.
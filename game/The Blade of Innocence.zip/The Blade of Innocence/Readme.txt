Title: The Blade of Innocence
Description:TThis expeditiously beautiful game has been developed by Bao Youyuan from China. The objective of the game is to build your castle research technology, gather gold, muster up the army to destroy your enemies. Now the fun part of the game is all of it happens on your screen without the need to scroll at all.


Downloaded from http://www.1station.org

Bookmark our site if you like US!


All the games belong to their respective owners.
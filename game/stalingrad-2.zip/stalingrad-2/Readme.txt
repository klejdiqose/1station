Title: Stalingrad 2


Description:
The objective of the game is to balance your base so that you will have enough resources to buy defense and units. You can build money factories, weapons and tank factories. Its up to you to strategise for the defense.


Souce from:http://www.freeonlinegames.com/game/stalingrad-2.html



Downloaded from http://www.1station.org!

Bookmark our site if you like US!


All the games belong to their respective owners.
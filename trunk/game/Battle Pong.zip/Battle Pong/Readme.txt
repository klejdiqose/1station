Title: Battle Pong
Description:This is a little more in-your-face than the original pong, what with rubber siding and all. Bounce your opponent away while keeping your side protected. Battle Pong is link Ping Pong and you got to defeat your enemy by playing the ball as good as possible. Avoid missing the ball for highscore! Win 2 points to play against the next opponent. Use mouse to move paddle. Cursors left/right to add spin and down for special.



Downloaded from http://www.1station.org

Bookmark our site if you like US!


All the games belong to their respective owners.
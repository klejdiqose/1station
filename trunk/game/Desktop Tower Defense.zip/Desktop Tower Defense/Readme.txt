Title: Desktop Tower Defense
Description:
According to the mode of difficulty you choose the creeps will either have one entrance or two entrances and exits. You can select the towers from the top left and place them anywhere on the map where its highlighted green. You can place it to create obstacles for the creeps and increase the time they need to get to the exit.



Downloaded from http://www.1station.org

Bookmark our site if you like US!


All the games belong to their respective owners.
Title: Gladiator: Swords and Sandals
Description:Gladiator, Sandals & Swords is a fighting game with strong RPG elements of creating character and weapon loadout.Create a gladiator, arm him up with a variety of armour and weapons, and send him into battle against a horde of crazy gladiators. Your character has to take down all the other Gladiators to become the ruling champion of the arena.



Downloaded from http://www.1station.org

Bookmark our site if you like US!


All the games belong to their respective owners.
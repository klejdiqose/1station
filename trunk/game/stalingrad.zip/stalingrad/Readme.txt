Title: Stalingrad
Description:
The objective of the game is to place defensive weapons in proper positions to guard your base. You lose life everytime an enemy unit gets through to your base. You can upgrade your defenses as you like. A strategy would be to try and be diverse because sticking to one type of weapon will not make you win. Try to kill all units for maximum gold and better defenses in the coming rounds. Watch our for air units! Have fun!
Souce from:http://www.freeonlinegames.com/game/stalingrad.html



Downloaded from http://www.1station.org

Bookmark our site if you like US!


All the games belong to their respective owners.